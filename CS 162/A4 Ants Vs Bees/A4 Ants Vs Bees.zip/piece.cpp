#include <iostream>
#include "piece.h"

using namespace std;


// Default constructor
Piece::Piece(){
	// cout << "Piece default constructor" << endl;
}
// Destructor
Piece::~Piece(){
	// cout << "Piece destructor" << endl;
}
