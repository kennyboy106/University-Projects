Simple game of Plants vs Zombies but copy right safe.
run make to get all the files then ./run