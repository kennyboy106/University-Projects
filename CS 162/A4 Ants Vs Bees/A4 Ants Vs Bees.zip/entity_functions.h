#ifndef ENTITY_FUNCTIONS_H
#define ENTITY_FUNCTIONS_H

#include "ant.h"
#include "bee.h"
#include "piece.h"
#include "tile.h"

using namespace std;
// Functions for ants //
bool tile_has_bee(vector<Piece*>);


#endif



