#include "tile.h"

Tile::Tile(){
	// cout << "Tile constructor" << endl;
	this->num_pieces = 0;
}

Tile::~Tile(){
	// cout << "Tile destructor" << endl;

}