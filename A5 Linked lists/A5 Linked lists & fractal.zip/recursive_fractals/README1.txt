Kenneth Tang 934308864
Description:
	This program will create a fractal depending on 2 inputs. The first is the
	number of stars you desire in the largest fractal that is an odd number
	The second is the column you wish this line to start from the left side
	of the terminal.
	It will then print out the fractal starting from 3 to the input number.
	After printing the largest star line, it will decrease down to 3 again.

Instructions:
	open the terminal in the folder and run:
		make
	Then use
		./run
	and follow the instructions of the program to step through the process.

Limitations:
	This doesn't work properly for even number
	There is no error handling so negative numbers will not work
	Must enter an odd number for the stars.
	Any number for spaces will work.