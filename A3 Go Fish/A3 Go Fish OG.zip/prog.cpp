#include <iostream>
#include <stdlib.h>
#include <time.h>

#include "Card.h"
#include "Deck.h"
#include "Hand.h"
#include "Player.h"
#include "Game.h"

using namespace std;

/******************************************************
** Program: Go_Fish.cpp
** Author: Kenneth Tang
** Date: 05/18/2022
** Description: A game of go fish with a computer that is heavily
*  reliant on classes and class functions
** Input:
** Output: Text to console or a specific file
******************************************************/


int main(int argn, char** argv){


	Game G1(argn, argv);
	G1.play_game();
}
