#ifndef CARD_H
#define CARD_H
#include <string>

using namespace std;

class Card{
private:
	int rank;
	int suit;


public:

	void set_rank(int);
	void set_suit(int);
	int get_rank();
	int get_suit();
	string map_suit();
	string map_rank();
	void print_card();
	//constructors
	Card();
	//Copy constructor
	Card(const Card&);
	// Assignment Overload
	const Card& operator=(const Card&);
	Card(int, int);


};



#endif